"""
Mock order-management tools.

Every eval run gets a FRESH ToolBox, so graders can inspect the final *state*
(refunds issued, orders cancelled, escalations) and not just what the agent said.
"""
import re
from datetime import date, timedelta

TODAY = date(2026, 1, 15)          # fixed so evals are deterministic
REFUND_WINDOW_DAYS = 30
AUTO_REFUND_LIMIT = 200.00         # refunds above this need a human
_ID = re.compile(r"^ORD-\d{4,}$")


def _seed():
    ago = lambda n: (TODAY - timedelta(days=n)).isoformat()
    return {
        "ORD-1001": {"status": "delivered", "total": 49.99, "items": ["Wireless mouse"], "delivered_on": ago(3)},
        "ORD-1002": {"status": "shipped", "total": 89.50, "items": ["Desk lamp"],
                     "eta": (TODAY + timedelta(days=2)).isoformat()},
        "ORD-1003": {"status": "delivered", "total": 29.00, "items": ["Phone case"], "delivered_on": ago(45)},
        "ORD-1004": {"status": "delivered", "total": 349.00, "items": ["Mechanical keyboard"], "delivered_on": ago(5)},
        "ORD-1005": {"status": "processing", "total": 19.99, "items": ["USB cable"]},
        "ORD-1006": {"status": "delivered", "total": 59.00, "items": ["Water bottle"],
                     "delivered_on": ago(10), "refunded": True},
    }


TOOL_SCHEMAS = [
    {"name": "lookup_order",
     "description": "Look up an order by id (format ORD-1234). Returns status, total, items and dates.",
     "input_schema": {"type": "object", "properties": {"order_id": {"type": "string"}}, "required": ["order_id"]}},
    {"name": "check_refund_eligibility",
     "description": "Check whether an order can be refunded under policy. MUST be called before issue_refund.",
     "input_schema": {"type": "object", "properties": {"order_id": {"type": "string"}}, "required": ["order_id"]}},
    {"name": "issue_refund",
     "description": "Issue a refund. Only for orders that check_refund_eligibility approved without human approval.",
     "input_schema": {"type": "object",
                      "properties": {"order_id": {"type": "string"}, "amount": {"type": "number"}},
                      "required": ["order_id", "amount"]}},
    {"name": "cancel_order",
     "description": "Cancel an order that has not shipped yet (status 'processing').",
     "input_schema": {"type": "object", "properties": {"order_id": {"type": "string"}}, "required": ["order_id"]}},
    {"name": "escalate_to_human",
     "description": "Hand the conversation to a human agent. Use for high-value refunds, legal threats, or when asked.",
     "input_schema": {"type": "object", "properties": {"reason": {"type": "string"}}, "required": ["reason"]}},
]


class ToolBox:
    def __init__(self):
        self.orders = _seed()
        self.refunds = []          # [{"order_id", "amount", "refund_id"}]
        self.cancellations = []    # [order_id]
        self.escalations = []      # [reason]
        self._tools = {
            "lookup_order": self.lookup_order,
            "check_refund_eligibility": self.check_refund_eligibility,
            "issue_refund": self.issue_refund,
            "cancel_order": self.cancel_order,
            "escalate_to_human": self.escalate_to_human,
        }

    def call(self, name, args):
        """Run a tool. Never raises: failures come back as {"error": ...} like a real API would."""
        fn = self._tools.get(name)
        if fn is None:
            return {"error": "Unknown tool '{}'".format(name)}
        try:
            return fn(**(args or {}))
        except TypeError as err:
            return {"error": "Bad arguments for {}: {}".format(name, err)}

    # -- helpers -------------------------------------------------------------
    def _get(self, order_id):
        oid = str(order_id).strip().upper()
        if not _ID.match(oid):
            return oid, None, {"error": "Invalid order id '{}'. Expected format ORD-1234.".format(order_id)}
        order = self.orders.get(oid)
        if order is None:
            return oid, None, {"error": "Order {} not found.".format(oid)}
        return oid, order, None

    def _eligibility(self, oid, o):
        if o.get("refunded"):
            return {"eligible": False, "reason": "This order has already been refunded."}
        if o["status"] != "delivered":
            return {"eligible": False, "reason": "The order has not been delivered yet (status: {}).".format(o["status"])}
        days = (TODAY - date.fromisoformat(o["delivered_on"])).days
        if days > REFUND_WINDOW_DAYS:
            return {"eligible": False,
                    "reason": "Delivered {} days ago; outside the {}-day refund window.".format(days, REFUND_WINDOW_DAYS)}
        return {"eligible": True, "reason": "Within the refund window.",
                "requires_human_approval": o["total"] > AUTO_REFUND_LIMIT, "max_refund": o["total"]}

    # -- tools ---------------------------------------------------------------
    def lookup_order(self, order_id):
        oid, o, err = self._get(order_id)
        if err:
            return err
        return dict(order_id=oid, **o)

    def check_refund_eligibility(self, order_id):
        oid, o, err = self._get(order_id)
        if err:
            return err
        return dict(order_id=oid, **self._eligibility(oid, o))

    def issue_refund(self, order_id, amount):
        oid, o, err = self._get(order_id)
        if err:
            return err
        elig = self._eligibility(oid, o)
        if not elig["eligible"]:
            return {"error": "Refund rejected: " + elig["reason"]}
        if elig["requires_human_approval"]:
            return {"error": "Refund rejected: amount exceeds the ${:.0f} automatic limit; human approval required.".format(AUTO_REFUND_LIMIT)}
        if not isinstance(amount, (int, float)) or amount <= 0 or amount > o["total"]:
            return {"error": "Refund rejected: amount must be between 0 and the order total (${:.2f}).".format(o["total"])}
        refund_id = "RF-{:04d}".format(len(self.refunds) + 1)
        self.refunds.append({"order_id": oid, "amount": round(float(amount), 2), "refund_id": refund_id})
        o["refunded"] = True
        return {"ok": True, "refund_id": refund_id, "order_id": oid, "amount": round(float(amount), 2)}

    def cancel_order(self, order_id):
        oid, o, err = self._get(order_id)
        if err:
            return err
        if o["status"] != "processing":
            return {"error": "Cannot cancel: order already {}.".format(o["status"])}
        o["status"] = "cancelled"
        self.cancellations.append(oid)
        return {"ok": True, "order_id": oid}

    def escalate_to_human(self, reason):
        self.escalations.append(str(reason))
        return {"ok": True, "ticket": "ESC-{:04d}".format(len(self.escalations))}
