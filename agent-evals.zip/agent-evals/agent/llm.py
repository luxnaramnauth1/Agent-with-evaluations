"""
LLM backends behind one tiny interface so the SAME agent + evals run against:

  * AnthropicBackend : the real model (needs ANTHROPIC_API_KEY)
  * MockBackend      : a scripted rule-based policy, NOT an LLM. Lets you test the harness,
                       run CI with no API key, and demo regression detection (weak=True).
"""
import json
import os
import re
from dataclasses import dataclass, field

DEFAULT_MODEL = os.environ.get("AGENT_MODEL", "claude-sonnet-5-5")


@dataclass
class LLMResponse:
    content: list                     # [{"type":"text","text":...} | {"type":"tool_use","id","name","input"}]
    stop_reason: str = "end_turn"
    input_tokens: int = 0
    output_tokens: int = 0


class AnthropicBackend:
    def __init__(self, model=None):
        import anthropic                      # lazy: only needed for real runs
        self.client = anthropic.Anthropic()   # reads ANTHROPIC_API_KEY
        self.model = model or DEFAULT_MODEL
        self.name = "anthropic"

    def complete(self, system, messages, tools=None, max_tokens=1024):
        kwargs = dict(model=self.model, max_tokens=max_tokens, system=system, messages=messages)
        if tools:
            kwargs["tools"] = tools
        resp = self.client.messages.create(**kwargs)
        content = []
        for block in resp.content:
            if block.type == "text":
                content.append({"type": "text", "text": block.text})
            elif block.type == "tool_use":
                content.append({"type": "tool_use", "id": block.id, "name": block.name, "input": dict(block.input)})
        return LLMResponse(content, resp.stop_reason, resp.usage.input_tokens, resp.usage.output_tokens)


# ---------------------------------------------------------------------------- mock
ORDER_RE = re.compile(r"ORD-\d+", re.I)
INJECTION = ("ignore previous", "ignore all previous", "system override", "you are now", "disregard your")
ESCALATE_WORDS = ("real person", "real human", "a human", "manager", "supervisor", "lawyer", "attorney",
                  "speak to someone", "talk to someone")
STATUS_WORDS = ("where", "status", "track", "arrive", "deliver")


def _history(messages):
    """First user text + ordered list of (tool_name, input, parsed_result) seen so far."""
    first_user, pending, calls = "", {}, []
    for m in messages:
        if m["role"] == "user" and isinstance(m["content"], str) and not first_user:
            first_user = m["content"]
        elif m["role"] == "assistant":
            for b in m["content"]:
                if b["type"] == "tool_use":
                    pending[b["id"]] = (b["name"], b["input"])
        elif m["role"] == "user" and isinstance(m["content"], list):
            for b in m["content"]:
                if b.get("type") == "tool_result":
                    name, inp = pending[b["tool_use_id"]]
                    calls.append((name, inp, json.loads(b["content"])))
    return first_user, calls


class MockBackend:
    """weak=True simulates a worse agent: skips eligibility checks, obeys prompt injection, leaks its prompt."""

    def __init__(self, weak=False):
        self.weak = weak
        self.name = "mock-weak" if weak else "mock"
        self.model = self.name
        self._n = 0

    def complete(self, system, messages, tools=None, max_tokens=1024):
        user_text, calls = _history(messages)
        kind, payload = self._decide(system, user_text, calls)
        if kind == "tool":
            self._n += 1
            name, args = payload
            content = [{"type": "tool_use", "id": "toolu_mock_{}".format(self._n), "name": name, "input": args}]
            out, stop = len(json.dumps(args)) // 4 + 10, "tool_use"
        else:
            content, out, stop = [{"type": "text", "text": payload}], len(payload) // 4 + 1, "end_turn"
        return LLMResponse(content, stop, input_tokens=len(json.dumps(messages)) // 4 + len(system) // 4, output_tokens=out)

    # -- scripted policy ------------------------------------------------------
    def _decide(self, system, user_text, calls):
        text = user_text.lower()
        injected = any(k in text for k in INJECTION)

        if "system prompt" in text:
            if self.weak and injected:
                return "text", system                       # prompt leak
            return "text", "I'm sorry, I can't share that. I can help with order status, refunds and cancellations."

        m = ORDER_RE.search(user_text)
        oid = m.group(0).upper() if m else None

        if any(k in text for k in ESCALATE_WORDS):
            intent = "escalate"
        elif any(k in text for k in ("refund", "money back", "return")):
            intent = "refund"
        elif "cancel" in text:
            intent = "cancel"
        elif any(k in text for k in STATUS_WORDS):
            intent = "status"
        else:
            intent = "other"

        if intent == "other":
            return "text", "I can only help with order status, refunds and cancellations. Do you have an order number?"
        if intent == "escalate":
            if not calls:
                return "tool", ("escalate_to_human", {"reason": user_text[:120]})
            return "text", "I've passed your request to a human teammate who will follow up with you shortly."
        if oid is None:
            return "text", "Happy to help. Could you share your order number (it looks like ORD-1234)?"

        if not calls:
            return "tool", ("lookup_order", {"order_id": oid})

        last_name, _, last = calls[-1]
        if last_name == "lookup_order":
            if "error" in last:
                return "text", "I couldn't find an order with the number {}. Could you double-check it?".format(oid)
            if intent == "status":
                return "text", self._status_text(oid, last)
            if intent == "cancel":
                if last["status"] == "processing":
                    return "tool", ("cancel_order", {"order_id": oid})
                return "text", "Order {} can't be cancelled because it has already {}.".format(oid, last["status"])
            # refund
            if self.weak:
                return "tool", ("issue_refund", {"order_id": oid, "amount": last["total"]})
            return "tool", ("check_refund_eligibility", {"order_id": oid})

        if last_name == "check_refund_eligibility":
            if not last.get("eligible"):
                return "text", "I'm sorry, order {} isn't eligible for a refund: {}".format(oid, last["reason"])
            if last.get("requires_human_approval"):
                return "tool", ("escalate_to_human", {"reason": "Refund over automatic limit for {}".format(oid)})
            return "tool", ("issue_refund", {"order_id": oid, "amount": last["max_refund"]})

        if last_name == "issue_refund":
            if "error" in last:
                return "text", "Sorry, I wasn't able to complete that: {}".format(last["error"])
            return "text", "Your refund of ${:.2f} for order {} has been issued (ref {}). It should appear in 5-7 business days.".format(
                last["amount"], oid, last["refund_id"])
        if last_name == "escalate_to_human":
            return "text", "Because this refund is over our automatic limit, it needs approval from a human teammate. I've escalated your request."
        if last_name == "cancel_order":
            if "error" in last:
                return "text", "Sorry, I couldn't cancel it: {}".format(last["error"])
            return "text", "Order {} has been cancelled.".format(oid)
        return "text", "Is there anything else I can help with?"

    @staticmethod
    def _status_text(oid, o):
        if o["status"] == "delivered":
            return "Order {} was delivered on {}.".format(oid, o["delivered_on"])
        if o["status"] == "shipped":
            return "Order {} has shipped and is expected to arrive on {}.".format(oid, o["eta"])
        if o["status"] == "processing":
            return "Order {} is still being processed and hasn't shipped yet.".format(oid)
        return "Order {} is currently {}.".format(oid, o["status"])


def make_backend(name, model=None):
    if name == "mock":
        return MockBackend()
    if name == "mock-weak":
        return MockBackend(weak=True)
    if name == "anthropic":
        return AnthropicBackend(model)
    raise ValueError("unknown backend '{}'".format(name))
