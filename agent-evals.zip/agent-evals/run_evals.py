#!/usr/bin/env python3
"""
Run the agent eval suite.

  python run_evals.py                                   # offline, scripted mock agent
  python run_evals.py --backend anthropic --trials 3    # real model (needs ANTHROPIC_API_KEY)
  python run_evals.py --backend mock-weak --baseline baselines/baseline.json --fail-on-regression
"""
import argparse
import json
import os
import shutil
import sys

from agent.llm import make_backend
from evals import report, runner


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--backend", default="mock", choices=["mock", "mock-weak", "anthropic"])
    p.add_argument("--model", help="model id for --backend anthropic (default: $AGENT_MODEL)")
    p.add_argument("--cases", default="evals/cases.json")
    p.add_argument("--trials", type=int, default=1, help="repeat each case N times (measures flakiness)")
    p.add_argument("--only", help="run only cases whose id or category contains this text")
    p.add_argument("--judge", action="store_true", help="add an LLM-as-judge check (anthropic backend only)")
    p.add_argument("--baseline", help="earlier run.json to compare against")
    p.add_argument("--min-pass-rate", type=float, help="exit 1 if pass rate is below this (0-1)")
    p.add_argument("--fail-on-regression", action="store_true", help="exit 1 if any baseline-passing case now fails")
    p.add_argument("--out-dir", default="results")
    args = p.parse_args(argv)

    cases, sha = runner.load_cases(args.cases)
    if args.only:
        cases = [c for c in cases if args.only in c["id"] or args.only in c["category"]]
    if not cases:
        print("no cases selected"); return 2

    backend = make_backend(args.backend, args.model)
    judge = backend if (args.judge and args.backend == "anthropic") else None
    if args.judge and judge is None:
        print("note: --judge is only used with --backend anthropic; skipping")

    def show(rec):
        print("  {} {:<26} {}".format("PASS" if rec["passed"] else "FAIL", rec["id"], rec["category"]))
    print("Running {} cases x {} trial(s) on {}".format(len(cases), args.trials, backend.name))
    results = runner.run_suite(backend, cases, args.trials, judge, show)
    result = runner.build_result(backend, sha, args.trials, results, judge is not None)

    comparison = None
    if args.baseline:
        with open(args.baseline) as fh:
            comparison = runner.compare(json.load(fh), result)

    os.makedirs(os.path.join(args.out_dir, "history"), exist_ok=True)
    run_path = os.path.join(args.out_dir, "run.json")
    with open(run_path, "w") as fh:
        json.dump(result, fh, indent=1)
    shutil.copy(run_path, os.path.join(args.out_dir, "history", "run-{}-{}.json".format(
        result["meta"]["timestamp"].replace(":", ""), backend.name)))
    with open(os.path.join(args.out_dir, "report.html"), "w") as fh:
        fh.write(report.render_html(result, comparison))
    md = report.render_markdown(result, comparison)
    with open(os.path.join(args.out_dir, "summary.md"), "w") as fh:
        fh.write(md)

    print("\n" + md)
    print("Dashboard: {}".format(os.path.join(args.out_dir, "report.html")))

    s = result["summary"]
    if args.min_pass_rate is not None and s["pass_rate"] < args.min_pass_rate:
        print("FAIL: pass rate {:.0%} below required {:.0%}".format(s["pass_rate"], args.min_pass_rate)); return 1
    if args.fail_on_regression and comparison and comparison["regressions"]:
        print("FAIL: regressions vs baseline: {}".format(", ".join(comparison["regressions"]))); return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
