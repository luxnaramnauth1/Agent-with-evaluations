import json
import os
import tempfile
import unittest
from unittest import mock

import run_evals
from agent.llm import LLMResponse, MockBackend
from evals import report, runner

CASES, SHA = runner.load_cases("evals/cases.json")


class RunnerTests(unittest.TestCase):
    def run_backend(self, backend, trials=1):
        return runner.build_result(backend, SHA, trials, runner.run_suite(backend, CASES, trials), False)

    def test_good_mock_passes_everything(self):
        r = self.run_backend(MockBackend())
        self.assertEqual(r["summary"]["cases_passed"], len(CASES))
        self.assertEqual(r["summary"]["pass_rate"], 1.0)

    def test_weak_mock_is_caught(self):
        r = self.run_backend(MockBackend(weak=True))
        self.assertLess(r["summary"]["pass_rate"], 0.8)
        self.assertEqual(r["summary"]["by_category"]["safety"]["passed"], 0)
        self.assertEqual(r["summary"]["by_category"]["status"]["passed"], 5)

    def test_compare_finds_regressions_and_improvements(self):
        good, weak = self.run_backend(MockBackend()), self.run_backend(MockBackend(weak=True))
        reg = runner.compare(good, weak)
        self.assertIn("injection-leak-prompt", reg["regressions"])
        self.assertEqual(reg["improvements"], [])
        self.assertLess(reg["pass_rate_delta"], 0)
        imp = runner.compare(weak, good)
        self.assertEqual(sorted(imp["improvements"]), sorted(reg["regressions"]))
        self.assertEqual(imp["regressions"], [])

    def test_trials_expose_flaky_behaviour(self):
        class Flaky(MockBackend):
            """Behaves like the weak agent on every other run."""
            def __init__(self):
                super().__init__()
                self.runs, self._last_first = 0, None

            def complete(self, system, messages, tools=None, max_tokens=1024):
                if len(messages) == 1:
                    self.runs += 1
                self.weak = self.runs % 2 == 0
                return super().complete(system, messages, tools, max_tokens)
        cases = [c for c in CASES if c["id"] == "refund-outside-window"]
        r = runner.build_result(Flaky(), SHA, 2, runner.run_suite(Flaky(), cases, trials=2), False)
        self.assertEqual(r["summary"]["flaky_cases"], ["refund-outside-window"])
        self.assertFalse(r["cases"][0]["passed"])
        self.assertEqual(r["cases"][0]["trial_pass_rate"], 0.5)

    def test_cost_only_when_prices_configured(self):
        self.assertIsNone(runner.estimate_cost(1000, 1000))
        with mock.patch.dict(os.environ, {"PRICE_IN_PER_MTOK": "3", "PRICE_OUT_PER_MTOK": "15"}):
            self.assertAlmostEqual(runner.estimate_cost(1_000_000, 1_000_000), 18.0)

    def test_summary_tool_error_rate(self):
        r = self.run_backend(MockBackend(weak=True))
        self.assertGreater(r["summary"]["tool_error_rate"], 0)


class ReportTests(unittest.TestCase):
    def test_html_escapes_untrusted_text(self):
        res = runner.build_result(MockBackend(), SHA, 1, runner.run_suite(
            MockBackend(), [{"id": "x<script>", "category": "c", "input": "<img src=x onerror=alert(1)>", "expect": {}}], 1), False)
        html = report.render_html(res)
        self.assertNotIn("<script>", html)
        self.assertNotIn("<img src=x", html)
        self.assertIn("&lt;script&gt;", html)

    def test_html_and_markdown_include_comparison(self):
        good = runner.build_result(MockBackend(), SHA, 1, runner.run_suite(MockBackend(), CASES, 1), False)
        weak = runner.build_result(MockBackend(weak=True), SHA, 1, runner.run_suite(MockBackend(weak=True), CASES, 1), False)
        cmp_ = runner.compare(good, weak)
        html, md = report.render_html(weak, cmp_), report.render_markdown(weak, cmp_)
        self.assertIn("Comparison vs baseline", html)
        self.assertIn("Regressions", html)
        self.assertIn("vs baseline", md)
        self.assertIn("injection-leak-prompt", md)


class CliTests(unittest.TestCase):
    def setUp(self):
        self.out = tempfile.mkdtemp()

    def run_cli(self, *args):
        with mock.patch("sys.stdout"):
            return run_evals.main(["--out-dir", self.out] + list(args))

    def test_good_agent_exit_zero_and_files_written(self):
        self.assertEqual(self.run_cli("--min-pass-rate", "0.95"), 0)
        for f in ["run.json", "report.html", "summary.md"]:
            self.assertTrue(os.path.exists(os.path.join(self.out, f)), f)

    def test_regression_gate_exits_one(self):
        self.assertEqual(self.run_cli("--backend", "mock-weak", "--baseline", "baselines/baseline.json", "--fail-on-regression"), 1)

    def test_min_pass_rate_gate_exits_one(self):
        self.assertEqual(self.run_cli("--backend", "mock-weak", "--min-pass-rate", "0.9"), 1)

    def test_only_filter(self):
        self.assertEqual(self.run_cli("--only", "safety"), 0)
        with open(os.path.join(self.out, "run.json")) as fh:
            self.assertEqual(json.load(fh)["summary"]["cases_total"], 3)

    def test_empty_selection_exits_two(self):
        self.assertEqual(self.run_cli("--only", "no-such-case"), 2)

    def test_case_file_is_well_formed(self):
        ids = [c["id"] for c in CASES]
        self.assertEqual(len(ids), len(set(ids)), "duplicate case ids")
        for c in CASES:
            self.assertTrue({"id", "category", "input", "expect"} <= set(c))


if __name__ == "__main__":
    unittest.main()
