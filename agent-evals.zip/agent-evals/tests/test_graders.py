import unittest

from agent.agent import ToolCall, Trace
from agent.tools import ToolBox
from evals.graders import grade, llm_judge
from agent.llm import LLMResponse


def trace(names=(), text="", stopped="end_turn", steps=1, err=False):
    return Trace("q", text, [ToolCall(n, {}, {"error": "x"} if err else {}, err) for n in names], steps, stopped_reason=stopped)


def failed(checks):
    return {c["name"] for c in checks if not c["passed"]}


class GraderTests(unittest.TestCase):
    def test_tools_called_and_not_called(self):
        case = {"expect": {"tools_called": ["a"], "tools_not_called": ["b"]}}
        self.assertEqual(failed(grade(case, trace(["a"]), ToolBox())), set())
        self.assertEqual(failed(grade(case, trace(["b"]), ToolBox())), {"tools_called", "tools_not_called"})

    def test_tool_order_is_subsequence(self):
        case = {"expect": {"tool_order": ["a", "c"]}}
        self.assertEqual(failed(grade(case, trace(["a", "b", "c"]), ToolBox())), set())
        self.assertEqual(failed(grade(case, trace(["c", "a"]), ToolBox())), {"tool_order"})

    def test_text_checks_are_case_insensitive(self):
        case = {"expect": {"final_contains_any": ["SHIPPED"], "final_not_contains": ["secret"]}}
        self.assertEqual(failed(grade(case, trace(text="It has shipped"), ToolBox())), set())
        self.assertEqual(failed(grade(case, trace(text="secret"), ToolBox())), {"final_contains", "final_not_contains"})

    def test_state_checks(self):
        tb = ToolBox()
        tb.call("issue_refund", {"order_id": "ORD-1001", "amount": 49.99})
        ok = {"expect": {"refunds": [{"order_id": "ORD-1001", "amount": 49.99}], "escalated": False}}
        self.assertEqual(failed(grade(ok, trace(), tb)), set())
        self.assertEqual(failed(grade({"expect": {"refunds": "none"}}, trace(), tb)), {"refunds"})

    def test_incomplete_run_fails(self):
        self.assertIn("completed", failed(grade({"expect": {}}, trace(stopped="max_steps"), ToolBox())))

    def test_efficiency_and_tool_errors(self):
        case = {"expect": {"max_steps": 2, "no_tool_errors": True}}
        self.assertEqual(failed(grade(case, trace(["a"], steps=5, err=True), ToolBox())), {"max_steps", "no_tool_errors"})


class FakeJudge:
    def __init__(self, raw):
        self.raw = raw

    def complete(self, system, messages, tools=None, max_tokens=0):
        return LLMResponse([{"type": "text", "text": self.raw}])


class JudgeTests(unittest.TestCase):
    def test_pass_and_fail_scores(self):
        t = trace(text="hello")
        self.assertTrue(llm_judge(FakeJudge('{"score": 5, "reason": "good"}'), {"input": "q"}, t)["passed"])
        self.assertFalse(llm_judge(FakeJudge('Sure! {"score": 2, "reason": "rude"}'), {"input": "q"}, t)["passed"])

    def test_unparseable_judge_output_fails_safely(self):
        r = llm_judge(FakeJudge("no json here"), {"input": "q"}, trace())
        self.assertFalse(r["passed"])
        self.assertIn("judge failed", r["detail"])


if __name__ == "__main__":
    unittest.main()
