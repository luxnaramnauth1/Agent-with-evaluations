import unittest

from agent.agent import run_agent
from agent.llm import LLMResponse
from agent.tools import ToolBox


class Scripted:
    name = "scripted"

    def __init__(self, steps):
        self.steps, self.calls = list(steps), []

    def complete(self, system, messages, tools=None, max_tokens=1024):
        self.calls.append(list(messages))   # snapshot: the agent keeps appending to the live list
        return self.steps.pop(0)


def tool_use(name, args, i=1):
    return LLMResponse([{"type": "tool_use", "id": "t{}".format(i), "name": name, "input": args}], "tool_use", 10, 5)


def text(t):
    return LLMResponse([{"type": "text", "text": t}], "end_turn", 10, 5)


class AgentTests(unittest.TestCase):
    def test_tool_loop_and_final_text(self):
        b = Scripted([tool_use("lookup_order", {"order_id": "ORD-1001"}), text("Delivered.")])
        t = run_agent("hi", b, ToolBox())
        self.assertEqual(t.final_text, "Delivered.")
        self.assertEqual(t.steps, 2)
        self.assertEqual(t.tool_calls[0].name, "lookup_order")
        self.assertFalse(t.tool_calls[0].error)
        self.assertEqual((t.input_tokens, t.output_tokens), (20, 10))
        # the tool result was fed back to the model
        self.assertEqual(b.calls[1][-1]["content"][0]["type"], "tool_result")

    def test_tool_errors_are_recorded_not_raised(self):
        t = run_agent("x", Scripted([tool_use("lookup_order", {"order_id": "nope"}), text("ok")]), ToolBox())
        self.assertTrue(t.tool_calls[0].error)

    def test_max_steps_stops_infinite_loops(self):
        b = Scripted([tool_use("lookup_order", {"order_id": "ORD-1001"}, i) for i in range(20)])
        t = run_agent("x", b, ToolBox(), max_steps=3)
        self.assertEqual(t.stopped_reason, "max_steps")
        self.assertEqual(t.steps, 3)

    def test_backend_exception_is_captured(self):
        class Boom:
            name = "boom"
            def complete(self, *a, **k):
                raise RuntimeError("rate limited")
        t = run_agent("x", Boom(), ToolBox())
        self.assertEqual(t.stopped_reason, "error")
        self.assertIn("rate limited", t.error)


if __name__ == "__main__":
    unittest.main()
