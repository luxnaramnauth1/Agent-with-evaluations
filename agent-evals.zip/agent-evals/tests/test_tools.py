import unittest

from agent.tools import ToolBox


class ToolTests(unittest.TestCase):
    def setUp(self):
        self.tb = ToolBox()

    def test_lookup_normalizes_id(self):
        self.assertEqual(self.tb.call("lookup_order", {"order_id": " ord-1001 "})["order_id"], "ORD-1001")

    def test_lookup_unknown_and_invalid(self):
        self.assertIn("not found", self.tb.call("lookup_order", {"order_id": "ORD-9999"})["error"])
        self.assertIn("Invalid", self.tb.call("lookup_order", {"order_id": "banana"})["error"])

    def test_unknown_tool_and_bad_args_do_not_raise(self):
        self.assertIn("Unknown tool", self.tb.call("rm_rf", {})["error"])
        self.assertIn("Bad arguments", self.tb.call("lookup_order", {"wrong": 1})["error"])

    def test_refund_happy_path_and_double_refund_blocked(self):
        self.assertTrue(self.tb.call("issue_refund", {"order_id": "ORD-1001", "amount": 49.99})["ok"])
        self.assertIn("error", self.tb.call("issue_refund", {"order_id": "ORD-1001", "amount": 49.99}))
        self.assertEqual(len(self.tb.refunds), 1)

    def test_server_side_guards_even_if_agent_misbehaves(self):
        for oid in ["ORD-1002", "ORD-1003", "ORD-1004", "ORD-1005", "ORD-1006"]:
            self.assertIn("error", self.tb.call("issue_refund", {"order_id": oid, "amount": 10}), oid)
        self.assertEqual(self.tb.refunds, [])

    def test_refund_amount_cannot_exceed_total(self):
        self.assertIn("error", self.tb.call("issue_refund", {"order_id": "ORD-1001", "amount": 500}))

    def test_eligibility_flags_high_value(self):
        r = self.tb.call("check_refund_eligibility", {"order_id": "ORD-1004"})
        self.assertTrue(r["eligible"])
        self.assertTrue(r["requires_human_approval"])

    def test_cancel_only_processing(self):
        self.assertTrue(self.tb.call("cancel_order", {"order_id": "ORD-1005"})["ok"])
        self.assertIn("error", self.tb.call("cancel_order", {"order_id": "ORD-1002"}))
        self.assertEqual(self.tb.cancellations, ["ORD-1005"])

    def test_fresh_toolbox_has_fresh_state(self):
        self.tb.call("cancel_order", {"order_id": "ORD-1005"})
        self.assertEqual(ToolBox().orders["ORD-1005"]["status"], "processing")


if __name__ == "__main__":
    unittest.main()
