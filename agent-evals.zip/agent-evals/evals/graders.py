"""
Deterministic graders (plus an optional LLM judge).

A case passes only if EVERY check passes. Graders look at three things:
  * what the agent SAID          (final_contains_*, final_not_contains)
  * what the agent DID           (tools_called, tools_not_called, tool_order, no_tool_errors)
  * what actually CHANGED        (refunds, cancelled, escalated)  <- state-based, hardest to game
plus efficiency (max_steps). See evals/cases.json for examples.
"""
import json
import re


def _check(name, passed, detail=""):
    return {"name": name, "passed": bool(passed), "detail": detail}


def _is_subsequence(wanted, actual):
    it = iter(actual)
    return all(any(w == a for a in it) for w in wanted)


def _norm_money(items):
    return sorted((i["order_id"], round(float(i["amount"]), 2)) for i in items)


def grade(case, trace, toolbox):
    e = case.get("expect", {})
    names = [tc.name for tc in trace.tool_calls]
    text = (trace.final_text or "").lower()
    checks = [_check("completed", trace.stopped_reason == "end_turn",
                     "" if trace.stopped_reason == "end_turn" else "{} {}".format(trace.stopped_reason, trace.error or ""))]

    if "tools_called" in e:
        missing = [t for t in e["tools_called"] if t not in names]
        checks.append(_check("tools_called", not missing, "missing: {}".format(missing) if missing else ""))
    if "tools_not_called" in e:
        forbidden = [t for t in e["tools_not_called"] if t in names]
        checks.append(_check("tools_not_called", not forbidden, "called forbidden: {}".format(forbidden) if forbidden else ""))
    if "tool_order" in e:
        ok = _is_subsequence(e["tool_order"], names)
        checks.append(_check("tool_order", ok, "" if ok else "expected {} in order, got {}".format(e["tool_order"], names)))
    if e.get("no_tool_errors"):
        errs = [tc.name for tc in trace.tool_calls if tc.error]
        checks.append(_check("no_tool_errors", not errs, "tool errors from: {}".format(errs) if errs else ""))

    if "final_contains_any" in e:
        ok = any(s.lower() in text for s in e["final_contains_any"])
        checks.append(_check("final_contains", ok, "" if ok else "none of {} found".format(e["final_contains_any"])))
    if "final_contains_all" in e:
        miss = [s for s in e["final_contains_all"] if s.lower() not in text]
        checks.append(_check("final_contains", not miss, "missing: {}".format(miss) if miss else ""))
    if "final_not_contains" in e:
        bad = [s for s in e["final_not_contains"] if s.lower() in text]
        checks.append(_check("final_not_contains", not bad, "reply contains: {}".format(bad) if bad else ""))

    if "refunds" in e:
        want = [] if e["refunds"] == "none" else _norm_money(e["refunds"])
        got = _norm_money(toolbox.refunds)
        checks.append(_check("refunds", want == got, "" if want == got else "expected {}, got {}".format(want, got)))
    if "cancelled" in e:
        want = [] if e["cancelled"] == "none" else sorted(e["cancelled"])
        got = sorted(toolbox.cancellations)
        checks.append(_check("cancelled", want == got, "" if want == got else "expected {}, got {}".format(want, got)))
    if "escalated" in e:
        got = bool(toolbox.escalations)
        checks.append(_check("escalated", got == e["escalated"], "" if got == e["escalated"] else "escalated={}".format(got)))
    if "max_steps" in e:
        checks.append(_check("max_steps", trace.steps <= e["max_steps"], "{} steps (limit {})".format(trace.steps, e["max_steps"])))
    return checks


JUDGE_SYSTEM = ("You are a strict QA reviewer for a customer-support assistant. Rate the assistant's FINAL REPLY from 1 to 5 "
                "for accuracy against the tool results, helpfulness, and a polite professional tone. "
                'Respond with JSON only: {"score": <1-5>, "reason": "<one sentence>"}')


def llm_judge(backend, case, trace, pass_score=4):
    """Optional LLM-as-judge check. Works with any backend exposing .complete()."""
    tools = "; ".join("{}({}) -> {}".format(t.name, json.dumps(t.input), json.dumps(t.output)) for t in trace.tool_calls) or "none"
    prompt = "Customer message: {}\nTool calls: {}\nFinal reply: {}".format(case["input"], tools, trace.final_text)
    try:
        resp = backend.complete(JUDGE_SYSTEM, [{"role": "user", "content": prompt}], tools=None, max_tokens=200)
        raw = " ".join(b["text"] for b in resp.content if b["type"] == "text")
        data = json.loads(re.search(r"\{.*\}", raw, re.S).group(0))
        score = int(data["score"])
        return _check("judge", score >= pass_score, "score {}/5: {}".format(score, data.get("reason", "")))
    except Exception as err:
        return _check("judge", False, "judge failed: {}: {}".format(type(err).__name__, err))
