"""Self-contained HTML dashboard (no external assets) and a Markdown summary for CI logs / PR comments."""
from html import escape as esc
import json


def _pct(x):
    return "{:.0f}%".format(100 * x)


def _bar(rate):
    cls = "ok" if rate >= 0.9 else ("warn" if rate >= 0.7 else "bad")
    return '<div class="bar"><div class="fill {}" style="width:{:.0f}%"></div></div>'.format(cls, 100 * rate)


CSS = """
:root{--bg:#fff;--fg:#1a1a1a;--mut:#667;--card:#f5f6f8;--line:#dde;--ok:#1a7f4b;--bad:#c62828;--warn:#b26a00}
@media (prefers-color-scheme:dark){:root{--bg:#14161a;--fg:#e8e8ea;--mut:#9aa;--card:#1e2127;--line:#323740;--ok:#4cc38a;--bad:#ff6b6b;--warn:#f0b24a}}
*{box-sizing:border-box}body{font:15px/1.5 system-ui,sans-serif;background:var(--bg);color:var(--fg);margin:0;padding:24px;max-width:1000px;margin:auto}
h1{margin:0 0 4px}h2{margin:32px 0 12px;font-size:18px}.sub{color:var(--mut);margin-bottom:20px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.kpi{background:var(--card);border-radius:10px;padding:14px}.kpi b{display:block;font-size:26px}.kpi span{color:var(--mut);font-size:13px}
table{width:100%;border-collapse:collapse}td,th{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:middle}
.bar{background:var(--card);border-radius:6px;height:10px;width:100%;min-width:120px;overflow:hidden}.fill{height:100%}
.fill.ok{background:var(--ok)}.fill.warn{background:var(--warn)}.fill.bad{background:var(--bad)}
.badge{padding:2px 8px;border-radius:99px;font-size:12px;font-weight:600;color:#fff}.badge.pass{background:var(--ok)}.badge.fail{background:var(--bad)}
details{border:1px solid var(--line);border-radius:8px;margin:6px 0;padding:0 12px}summary{cursor:pointer;padding:10px 0;display:flex;gap:10px;align-items:center}
summary .id{font-weight:600}.cat{color:var(--mut);font-size:13px}.body{padding:4px 0 12px}
pre{background:var(--card);padding:8px 10px;border-radius:6px;overflow-x:auto;font-size:12.5px;margin:4px 0}
.fail-t{color:var(--bad)}.pass-t{color:var(--ok)}.cmp{background:var(--card);border-left:4px solid var(--warn);padding:12px 16px;border-radius:6px}
.scroll{overflow-x:auto}
"""


def render_html(result, comparison=None):
    m, s = result["meta"], result["summary"]
    cost = "n/a" if s["est_cost_usd"] is None else "${:.3f}".format(s["est_cost_usd"])
    kpis = [(_pct(s["pass_rate"]), "pass rate ({} trials)".format(s["trials_total"])),
            ("{}/{}".format(s["cases_passed"], s["cases_total"]), "cases passing"),
            ("{:.1f}".format(s["avg_steps"]), "avg model steps"),
            ("{:.2f}s".format(s["avg_latency_s"]), "avg latency"),
            ("{:,}".format(s["input_tokens"] + s["output_tokens"]), "total tokens"),
            (cost, "est. cost"), (_pct(s["tool_error_rate"]), "tool error rate")]
    h = ["<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>",
         "<title>Agent eval report</title><style>{}</style></head><body>".format(CSS),
         "<h1>Agent eval report</h1><div class='sub'>backend <b>{}</b> · model <b>{}</b> · {} · {} trial(s)/case · cases hash {}</div>".format(
             esc(m["backend"]), esc(str(m["model"])), esc(m["timestamp"]), m["trials"], esc(m["cases_sha"])),
         "<div class='kpis'>" + "".join("<div class='kpi'><b>{}</b><span>{}</span></div>".format(esc(a), esc(b)) for a, b in kpis) + "</div>"]

    if comparison:
        d = comparison["pass_rate_delta"]
        h.append("<h2>Comparison vs baseline</h2><div class='cmp'>Baseline: {}<br>Pass-rate change: <b>{:+.1f} pts</b><br>".format(
            esc(comparison["base_label"]), 100 * d))
        h.append("<b class='fail-t'>Regressions ({}):</b> {}<br>".format(len(comparison["regressions"]), esc(", ".join(comparison["regressions"]) or "none")))
        h.append("<b class='pass-t'>Improvements ({}):</b> {}".format(len(comparison["improvements"]), esc(", ".join(comparison["improvements"]) or "none")))
        if comparison["cases_changed"]:
            h.append("<br><i>Note: the case file changed since the baseline, so numbers are not like-for-like.</i>")
        h.append("</div>")

    h.append("<h2>By category</h2><div class='scroll'><table>")
    for cat, v in s["by_category"].items():
        h.append("<tr><td>{}</td><td>{}/{}</td><td style='width:45%'>{}</td><td>{}</td></tr>".format(
            esc(cat), v["passed"], v["cases"], _bar(v["pass_rate"]), _pct(v["pass_rate"])))
    h.append("</table></div><h2>By check type</h2><div class='scroll'><table>")
    for name, v in s["by_check"].items():
        h.append("<tr><td>{}</td><td>{}/{}</td><td style='width:45%'>{}</td><td>{}</td></tr>".format(
            esc(name), v["passed"], v["total"], _bar(v["rate"]), _pct(v["rate"])))
    h.append("</table></div>")
    if s["flaky_cases"]:
        h.append("<h2>Flaky cases</h2><p>{}</p>".format(esc(", ".join(s["flaky_cases"]))))

    h.append("<h2>Cases</h2>")
    for c in sorted(result["cases"], key=lambda c: c["passed"]):      # failures first
        bad = next((x for x in c["trials"] if not x["passed"]), c["trials"][0])
        h.append("<details{}><summary><span class='badge {}'>{}</span><span class='id'>{}</span><span class='cat'>{} · {}/{} trials</span></summary><div class='body'>".format(
            "" if c["passed"] else " open", "pass" if c["passed"] else "fail", "PASS" if c["passed"] else "FAIL",
            esc(c["id"]), esc(c["category"]), sum(x["passed"] for x in c["trials"]), len(c["trials"])))
        h.append("<div><b>Customer:</b> {}</div>".format(esc(c["input"])))
        calls = "\n".join("{}({}) -> {}".format(x["name"], json.dumps(x["input"]), json.dumps(x["output"])) for x in bad["tool_calls"]) or "(no tool calls)"
        h.append("<pre>{}</pre><div><b>Agent reply:</b> {}</div><ul>".format(esc(calls), esc(bad["final_text"] or "(none)")))
        for ch in bad["checks"]:
            h.append("<li class='{}'>{} {}{}</li>".format("pass-t" if ch["passed"] else "fail-t", "✓" if ch["passed"] else "✗",
                                                           esc(ch["name"]), (" — " + esc(ch["detail"])) if ch["detail"] else ""))
        h.append("</ul></div></details>")
    h.append("</body></html>")
    return "".join(h)


def render_markdown(result, comparison=None):
    m, s = result["meta"], result["summary"]
    out = ["## Agent eval: {} ({})".format(m["backend"], m["model"]), "",
           "**Pass rate {:.0f}%** · {}/{} cases · avg {:.1f} steps · {:,} tokens".format(
               100 * s["pass_rate"], s["cases_passed"], s["cases_total"], s["avg_steps"], s["input_tokens"] + s["output_tokens"]), "",
           "| category | passed | rate |", "|---|---|---|"]
    out += ["| {} | {}/{} | {:.0f}% |".format(k, v["passed"], v["cases"], 100 * v["pass_rate"]) for k, v in s["by_category"].items()]
    if comparison:
        out += ["", "**vs baseline:** {:+.1f} pts · regressions: {} · improvements: {}".format(
            100 * comparison["pass_rate_delta"], ", ".join(comparison["regressions"]) or "none", ", ".join(comparison["improvements"]) or "none")]
    failed = [c for c in result["cases"] if not c["passed"]]
    if failed:
        out += ["", "**Failing cases:**"]
        for c in failed:
            t = next(x for x in c["trials"] if not x["passed"])
            why = "; ".join("{}: {}".format(k["name"], k["detail"]) for k in t["checks"] if not k["passed"])
            out.append("- `{}`: {}".format(c["id"], why))
    return "\n".join(out) + "\n"
