"""Run every case (optionally several trials), grade it, aggregate metrics, compare runs."""
import datetime
import hashlib
import json
import os
from collections import defaultdict

from agent.agent import run_agent
from agent.tools import ToolBox
from evals.graders import grade, llm_judge


def load_cases(path):
    with open(path, "rb") as fh:
        raw = fh.read()
    return json.loads(raw)["cases"], hashlib.sha256(raw).hexdigest()[:12]


def estimate_cost(in_tok, out_tok):
    """USD cost if you set PRICE_IN_PER_MTOK / PRICE_OUT_PER_MTOK (dollars per million tokens), else None."""
    p_in, p_out = os.environ.get("PRICE_IN_PER_MTOK"), os.environ.get("PRICE_OUT_PER_MTOK")
    if not p_in or not p_out:
        return None
    return round(in_tok / 1e6 * float(p_in) + out_tok / 1e6 * float(p_out), 4)


def run_suite(backend, cases, trials=1, judge_backend=None, on_case=None):
    results = []
    for case in cases:
        trial_records = []
        for _ in range(trials):
            tb = ToolBox()
            trace = run_agent(case["input"], backend, tb)
            checks = grade(case, trace, tb)
            if judge_backend is not None:
                checks.append(llm_judge(judge_backend, case, trace))
            trial_records.append({
                "passed": all(c["passed"] for c in checks), "checks": checks,
                "final_text": trace.final_text, "steps": trace.steps,
                "tool_calls": [{"name": t.name, "input": t.input, "output": t.output, "error": t.error} for t in trace.tool_calls],
                "input_tokens": trace.input_tokens, "output_tokens": trace.output_tokens,
                "latency_s": trace.latency_s, "stopped_reason": trace.stopped_reason, "error": trace.error,
            })
        passed_trials = sum(t["passed"] for t in trial_records)
        rec = {"id": case["id"], "category": case["category"], "input": case["input"],
               "passed": passed_trials == trials, "trial_pass_rate": passed_trials / trials, "trials": trial_records}
        results.append(rec)
        if on_case:
            on_case(rec)
    return results


def summarize(results):
    trials = [t for r in results for t in r["trials"]]
    n_trials = len(trials)
    by_cat, by_check = defaultdict(lambda: [0, 0]), defaultdict(lambda: [0, 0])
    for r in results:
        by_cat[r["category"]][0] += 1
        by_cat[r["category"]][1] += r["passed"]
        for t in r["trials"]:
            for c in t["checks"]:
                by_check[c["name"]][0] += 1
                by_check[c["name"]][1] += c["passed"]
    tool_calls = [tc for t in trials for tc in t["tool_calls"]]
    in_tok, out_tok = sum(t["input_tokens"] for t in trials), sum(t["output_tokens"] for t in trials)
    return {
        "cases_total": len(results), "cases_passed": sum(r["passed"] for r in results),
        "case_pass_rate": sum(r["passed"] for r in results) / len(results) if results else 0.0,
        "trials_total": n_trials, "trials_passed": sum(t["passed"] for t in trials),
        "pass_rate": sum(t["passed"] for t in trials) / n_trials if n_trials else 0.0,
        "flaky_cases": [r["id"] for r in results if 0 < r["trial_pass_rate"] < 1],
        "by_category": {k: {"cases": v[0], "passed": v[1], "pass_rate": v[1] / v[0]} for k, v in sorted(by_cat.items())},
        "by_check": {k: {"total": v[0], "passed": v[1], "rate": v[1] / v[0]} for k, v in sorted(by_check.items())},
        "avg_steps": sum(t["steps"] for t in trials) / n_trials if n_trials else 0.0,
        "avg_tool_calls": len(tool_calls) / n_trials if n_trials else 0.0,
        "tool_error_rate": (sum(tc["error"] for tc in tool_calls) / len(tool_calls)) if tool_calls else 0.0,
        "avg_latency_s": sum(t["latency_s"] for t in trials) / n_trials if n_trials else 0.0,
        "input_tokens": in_tok, "output_tokens": out_tok, "est_cost_usd": estimate_cost(in_tok, out_tok),
    }


def build_result(backend, cases_sha, trials, results, judged):
    return {
        "meta": {"backend": backend.name, "model": getattr(backend, "model", backend.name),
                 "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
                 "trials": trials, "cases_sha": cases_sha, "judge": judged},
        "summary": summarize(results), "cases": results,
    }


def compare(base, cand):
    b = {c["id"]: c["passed"] for c in base["cases"]}
    n = {c["id"]: c["passed"] for c in cand["cases"]}
    return {
        "base_label": "{} @ {}".format(base["meta"]["model"], base["meta"]["timestamp"]),
        "pass_rate_delta": cand["summary"]["pass_rate"] - base["summary"]["pass_rate"],
        "regressions": [i for i in n if i in b and b[i] and not n[i]],
        "improvements": [i for i in n if i in b and not b[i] and n[i]],
        "new_cases": [i for i in n if i not in b], "removed_cases": [i for i in b if i not in n],
        "cases_changed": base["meta"]["cases_sha"] != cand["meta"]["cases_sha"],
    }
